#include<iostream>
using namespace std;

int main()
{
	//Operators
	//Arithimetic operator
	//+,-,/,%,* // use for calulations
	
	//assignment operator
	// = // for assigning values to variables
	
	// a = a + b;
	// a += b;
	
	// a = a*b;
	// a *= b;
	
	
//	int a = 10;
//	
//	int b = 20;
//	
//	int c = a+b;
//	cout << c << endl;
//	
//	c = a-b;
//	cout << c << endl;
//	
//	c = a*b;
//	cout << c << endl;
//	
//	c = a/b;
//	cout << c << endl;
//	
//	c = a%b;
//	cout << c << endl;

//   declare vs define vs intialize
//   
//   declare  : int a; // compiler knows its existence but there is  not memory allocation
//   
//   define : declared variable get a value after some operation.
//
//   a = fibonaci(n);
//   
//   initialize : define a declared variable at the time of declaration.
//   
//   int a = 10;

//   Relational Operators or comparator o/p boolean
//   1. < or >
//   2. <= or >=
//   3. ==  // 5 == 5.0 true
//   4. !=

//   Logical operators o/p boolean
//   1. and or && 
     //0 && 0 == 0
     // 0 && 1 == 0
     // 1 && 1 == 1
    
// 2. or syntax : ||
   // 0 or 1 : 1
   // 1 or 1 : 1
   // 0 or 0 : 0

// 3. not syntax  : !
// true => false
// false => true

// 4. unary operator
// 1. ++ // int a = 1; a++; // 1 cout << a ; ++a; // 2
// 2. -- // int a = 2; a--; 1// cout << a; --a; // 1

}
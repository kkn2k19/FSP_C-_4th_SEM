#include<iostream>
using namespace std;

int main()
{
/*	int a;
	
	cout << "Enter value of integer : ";
	
	cin >> a;
	
	cout << a << endl;
	
	float b; // 4bytes
	
	cout << "Enter value of float : ";
	
	cin >> b;
	
	cout << b << endl;
	
	bool c; // true or false
	
	double d; // 8 bytes
	
	char ch;
	
	*/
	
	//takes input from user and print on console
	// name, age, marks, phone
	
	string name;
	
	getline(cin,name);
	
//	getline(cin,name);
	
	
	return 0;
}
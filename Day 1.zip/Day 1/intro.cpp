#include<iostream>
using namespace std;

int main()
{
	cout << "Hello World !!"; //console output
	cout << "Hello World !!";
	
	int n;
	
	cin >> n ; //console input
	
	cout << n;
	
	return 0;
}

//Tokens
//Small unit of a program that have special purpose
//1. Keyword : they are predefined keyword that have special purpose
//2. Indentifier : it refers to name of function, variable, constant, class and object etc
//3. Constants : they are also a type of variable that cannot be change
//4. Strings : everycharacter in double quotes "" or in single quotes ' ' and they are sequential collection of characters
//5. Operators : arthimetic, assignment, comparator or relational, bitwise etc
//6. Variables : variables are the container that store some values and they can be dynamic in nature

//Data types : types of data 

//System defined or predefined
//1. Integer : -1,-2,0,1,2....
//2. Float : 1.2, 0.5, -1.2..
//3. char : abc, a, hdfc
//4. boolean : true or false, 1 or 0

//User Defined
//1. Structure (struct)
//2. Class
//3. Union
//4. Enumeration





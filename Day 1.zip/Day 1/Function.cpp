#include<iostream>
using namespace std;

//function : function are a block of code that perform a certain task
// function : user defined and pre defined
// user defined : add(), average(), or twoSum()
// predefined : printf(), scanf() etc...

//parameterized function : these function need to fulfill their requirment to run.
//non parameterized function : they don't have any requirement.

int add(int a, int b) // parameter
{	
	return a + b;
}

int main()
{
	
	int a = 10;
	int b = 20;
	
	cout << add(a,b); //arguement
	
	return 0;
}

menu driven calculator using function, do-while loop, if else or switch case



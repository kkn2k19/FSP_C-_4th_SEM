#include<iostream>
using namespace std;

int main()
{
	//1. if
	
//	int n;
//	
//	cout << "Enter value of n : ";
//	cin >> n;
//	
//	if(n > 50)
//	{
//		cout << "Hello World";
//	}
	
	//2. if-else
	
//	int n;
//	
//	cout << "Enter value of n : ";
//	cin >> n;
//	
//	if(n > 50)
//	{
//		cout << "Hello World";
//	}
//	else
//	{
//		cout << "Bye Bye World";
//	}
	
	//3. ladder if-else
	
//	int n;
//	
//	cout << "Enter total marks : ";
//	cin >> n;
//	
//	if(n >= 90 && n <= 100)
//	{
//		cout << "Grade A";
//	}
//	else if(n >= 80 && n <= 90)
//	{
//		cout << "Grade B";
//	}
//	else if(n >= 70 && n <= 80)
//	{
//		cout << "Grade C";
//	}
//	else if(n >= 60 && n <= 70)
//	{
//		cout << "Grade D";
//	}
//	else if(n >= 50 && n <= 60)
//	{
//		cout << "Grade E";
//	}
//	else
//	{
//		cout << "Fail";
//	}

//ternary operator

//int a = 20;
//int b = 30;
//
//(a > b)? cout << a : cout << b;

//Loops

//for loop
	
//	for(int i = 1; i<=10; i++)
//	{
//		cout << i << endl;
//	}

//while 
//  int i = 1;
//  
//  while(i <= 10)
//  {
//  	cout << i << endl;
//  	i++;
//  }


//do-while

//   int i = 1;
//   
//   do{
//   	cout << i << endl;
//   	i++;
//   }while(i <= 10);

//break : break the flow of loop or exits the loop

//for(int i = 1; i <= 10; i++)
//{
//	if(i/5 == 1)
//	{
//		break;
//	}	
//	cout<<i<<endl;		
//}

//continue : skip the further code 

//for(int i = 1; i <= 10; i++)
//{	
//	if(i == 5)
//	{
//		continue;
//	}	
//	
//	cout<<i<<endl;			
//}




	
	return 0;
}

